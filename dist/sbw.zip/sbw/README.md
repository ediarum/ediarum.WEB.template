# Setup-docu ediarum.WEB

IMPORTANT: The software was be developed with exist-db 3.2.0

## 1. Upload files to existdb

The data files must be load into the collection "/db/projects/sbw/data" into the subcollections for letters "Briefe" and indexes "Register".

## 2. Install ediarum.WEB

Install the ediarum.web XAR-Package via Dashboard.

## 3. Install the project app

Install the sbw.WEB XAR-Package via Dashboard.

## 4. Start the project app

The website can be started via the Dashboard or with the URL: <http://localhost:8080/exist/apps/sbw.WEB/index.html>

